"""Punkt wejścia CLI — parsowanie argumentów (ticker, --save), inicjalizacja agenta,
uruchomienie pętli wyceny i wyświetlenie raportu w terminalu.

Użycie:
    python main.py AAPL
    python main.py CDR.WA --save
    python main.py PKN.WA --verbose --save
    python main.py MSFT --market USA -s -v
"""

import sys
import re
import argparse

# Wymuś UTF-8 na stdout/stderr — zapobiega UnicodeEncodeError w Windows
# gdy terminal używa starszej strony kodowej (cp1250, cp852 itp.).
# Musi być przed importem rich, żeby Console() od razu widział UTF-8 stream.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from rich.console import Console

console = Console(legacy_windows=False)


def detect_market(ticker: str) -> str:
    """Automatycznie rozpoznaje rynek na podstawie formatu tickera.

    Reguły:
    - Suffix .WA → GPW Warszawa
    - 1-5 wielkich liter bez kropki → NYSE/NASDAQ (USA)
    - Inny format → nierozpoznany
    """
    if ticker.upper().endswith(".WA"):
        return "GPW"
    if re.fullmatch(r"[A-Z]{1,5}", ticker.upper()):
        return "USA"
    return "UNKNOWN"


def parse_args() -> argparse.Namespace:
    """Parsuje argumenty wiersza poleceń."""
    parser = argparse.ArgumentParser(
        description="Agent AI do wyceny wartości rzeczywistej spółek giełdowych",
        epilog=(
            "Przykłady:\n"
            "  python main.py AAPL              — wycena Apple (NYSE)\n"
            "  python main.py CDR.WA --save     — wycena CD Projekt (GPW) + zapis\n"
            "  python main.py MSFT -s -v        — wycena Microsoft, zapis + logi\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "ticker",
        type=str,
        help="Ticker spółki, np. AAPL (NYSE) lub CDR.WA (GPW)",
    )
    parser.add_argument(
        "--fresh",
        action="store_true",
        help=(
            "Pomiń cache i pobierz świeże dane z yfinance. "
            "Używaj po wynikach kwartalnych lub dużych ruchach kursu."
        ),
    )
    parser.add_argument(
        "--save", "-s",
        action="store_true",
        help="Zapisz raport do pliku .md w folderze reports/",
    )
    parser.add_argument(
        "--market",
        type=str,
        choices=["GPW", "USA"],
        default=None,
        help="Rynek giełdowy (domyślnie: auto-detect na podstawie tickera)",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Wyświetlaj szczegółowe logi komunikacji z GPT-4o",
    )

    return parser.parse_args()


def main() -> None:
    """Główna funkcja programu — orkiestruje cały proces wyceny."""
    args = parse_args()

    ticker = args.ticker.upper()

    # Rozpoznanie rynku
    if args.market:
        market = args.market
    else:
        market = detect_market(ticker)

    if market == "UNKNOWN":
        console.print(
            f'[bold yellow]Nie rozpoznano rynku dla tickera "{ticker}".[/bold yellow]\n'
            "[dim]Uzyj formatu: AAPL (USA) lub CDR.WA (GPW).\n"
            "Mozesz tez podac rynek recznie: --market GPW lub --market USA[/dim]"
        )
        sys.exit(1)

    # Dla GPW: upewnij się, że ticker ma suffix .WA
    if market == "GPW" and not ticker.endswith(".WA"):
        ticker = f"{ticker}.WA"
        console.print(
            f"[dim]ℹ Rynek GPW — uzupełniono ticker do: {ticker}[/dim]"
        )

    # Banner powitalny
    console.print()
    console.print("[bold cyan]╔══════════════════════════════════════════════╗[/bold cyan]")
    console.print("[bold cyan]║   Valuation Agent AI — Wycena Spółek        ║[/bold cyan]")
    console.print("[bold cyan]╚══════════════════════════════════════════════╝[/bold cyan]")
    console.print(f"[dim]  Ticker: {ticker} | Rynek: {market}[/dim]")

    # Wczesna walidacja klucza API — czytelny komunikat zanim załadujemy ciężkie moduły
    from config import OPENAI_API_KEY
    if not OPENAI_API_KEY:
        console.print(
            "[bold red]Blad: Ustaw OPENAI_API_KEY w pliku .env[/bold red]\n"
            "[dim]Skopiuj .env.example do .env i wpisz swoj klucz OpenAI.[/dim]"
        )
        sys.exit(1)

    from agent.orchestrator import ValuationAgent
    from report.generator import display_report, save_report

    agent = ValuationAgent()

    # Uruchomienie pętli agenta
    report_text = agent.run(ticker, verbose=args.verbose, force_refresh=args.fresh)

    if report_text is None:
        console.print(
            f"\n[bold red]✗ Nie udało się wygenerować raportu dla {ticker}.[/bold red]"
        )
        sys.exit(1)

    # Wyświetlenie raportu w terminalu
    display_report(report_text, ticker)

    # Opcjonalny zapis do pliku
    if args.save:
        filepath = save_report(report_text, ticker, agent.tool_call_log)
        console.print(f"[dim]  Plik MD: {filepath}[/dim]")

        # Generuj PDF obok pliku Markdown
        try:
            from report.pdf_generator import generate_pdf
            pdf_path = generate_pdf(report_text, ticker)
            console.print(f"[dim]  Plik PDF: {pdf_path}[/dim]")
        except Exception as e:
            console.print(f"[yellow]  ⚠ PDF niedostępny: {e}[/yellow]")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n[yellow]Przerwano przez użytkownika.[/yellow]")
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"\n[bold red]✗ Nieoczekiwany błąd: {e}[/bold red]")
        sys.exit(1)
