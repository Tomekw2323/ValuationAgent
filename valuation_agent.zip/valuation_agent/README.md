# Valuation Agent AI

A GPT-4o-orchestrated equity valuation tool for US stocks and Warsaw Stock Exchange (GPW) companies, built as a learning project / portfolio demo.

## What it does

- **DCF** (single-stage and two-stage) with automatic CAPM-based WACC estimation from beta
- **Multiples** (P/E, EV/EBITDA, P/BV, EV/Sales) with IQR outlier removal and sector peer matching
- **DDM** for dividend-paying stocks, with spread stabilization when growth rate approaches required return
- **Sum-of-Parts (SOTP)** for AMZN and GOOGL — segments valued at different EV/Sales multiples
- **GPW discount adjustment** — Polish stocks discounted 15-25% vs. Western peers, calibrated by sector
- **Wide moat adjustment** — optional +0.5pp terminal growth for companies with durable competitive advantage
- **Buyback correction** — adjusts per-share DCF price upward when the company consistently reduces share count
- Analyst consensus pulled from yfinance and displayed alongside model output
- Streamlit UI + CLI (`main.py`) + PDF export

GPT-4o acts as an orchestrator: it decides which tools to call, in what order, and synthesizes results into a Polish-language narrative report. It does not perform the calculations itself.

## Architecture

```
user → Streamlit (app.py)
     → ValuationAgent.run() [agent/orchestrator.py]
       → GPT-4o tool-use loop (up to 10 iterations)
         → get_financial_data()   [tools/data_fetcher.py]  — yfinance + 24h file cache
         → run_dcf()              [tools/dcf.py]           — DCF, two-stage, buyback, moat
         → run_multiples()        [tools/multiples.py]     — P/E, EV/EBITDA, P/BV, GPW discount
         → run_ddm()              [tools/ddm.py]           — Gordon Growth Model
         → sensitivity_analysis() [tools/dcf.py]           — 3x3 WACC x growth matrix
         → run_sotp()             [tools/sotp.py]          — AMZN / GOOGL only
     → GPT-4o generates final Markdown report (in Polish)
```

## Quickstart

```bash

cd valuation-agent
pip install -r requirements.txt
cp .env.example .env
# Add your OpenAI API key to .env
streamlit run app.py
```

CLI alternative (outputs report to terminal + optional .md file):

```bash
python main.py AAPL
python main.py PKN.WA --fresh    # bypass 24h cache
python main.py CDR.WA --save     # save report to reports/
```

## Valuation methods

**DCF (single-stage)** — used when historical FCF growth is <= 10%. Projects FCF at a constant rate for 5 years, then applies a Gordon Growth terminal value.

**DCF (two-stage)** — activates automatically when historical FCF growth > 10%. Phase 1 (years 1-5): growth = average of historical and user-specified rate, capped at 20%. Phase 2 (years 6-10): growth declines linearly to terminal rate.

**DCF per-share** — fallback when standard EV to Equity math breaks down: negative book equity (e.g. KO, AAPL due to buybacks) or net debt > 40% of EV. Discounts FCF-per-share directly, bypassing the balance sheet.

**Multiples** — sector peers matched by industry first, sector-level fallback. Outliers removed via Tukey IQR before computing medians. Special handling for gaming companies: P/BV excluded from the median (IP-driven business), EV/Sales added instead.

**DDM** — triggered when the company has at least 3 years of dividend history. If implied growth rate comes within 0.5pp of the required return, it is capped at `required_return x 0.8` with a warning. Prevents the denominator from collapsing.

**SOTP** — hardcoded segment revenue estimates and EV/Sales multiples for AMZN and GOOGL. Treated as the primary method when applicable; standard DCF runs as a cross-check.

## Limitations

**DCF systematically undervalues asset-light and brand-driven companies.** KO and PEP trade at 20-25x FCF because the market prices brand durability and pricing power — a DCF built on last year's FCF will almost always say they are overvalued. The wide moat adjustment (+0.5pp terminal growth) partially mitigates this but does not solve the structural problem.

**yfinance data is delayed and sometimes wrong.** Financial statements reflect the last filed annual report, not trailing twelve months. Some GPW tickers return incomplete data or fail silently. Do not use this tool for any real investment decision without cross-checking against actual filings.

**Tesla has no appropriate peers.** The peer list uses EV pure-plays (RIVN, NIO, LCID) which are pre-revenue or loss-making. TSLA's multiples median is essentially noise — the tool flags this but cannot fix it.

**GPW discount is a rough heuristic.** The 15-25% sector discount is based on observed valuation gaps between Polish and Western companies, not a rigorous empirical model. It can be wrong in both directions.

**DDM is fragile near the stability boundary.** When dividend growth rate approaches the required return, small input changes cause large output swings. The stabilization cap reduces volatility but the result remains directional, not a precise price target.

**SOTP segment data is static.** Revenue estimates for AMZN and GOOGL segments are hardcoded from 2024 estimates and will become stale.

## Supported markets

| Market | Support level |
|--------|---------------|
| **USA** | Full: CAPM WACC, ~30 industries with dedicated peer lists, SOTP for AMZN/GOOGL |
| **GPW (Warsaw)** | Good: European/regional peers, GPW sector discount, `.WA` ticker detection |
| **Other exchanges** | Partial: works if yfinance returns data, but no custom peer lists or discount calibration |

## Known edge cases

| Company | Problem | How the agent handles it |
|---------|---------|--------------------------|
| TSLA | No meaningful comp set exists | EV pure-play peers + speculative premium note |
| KO, PEP, AAPL | Negative book equity from buybacks | Switches to DCF per-share automatically |
| PKO.WA, ING.WA | Banks: FCF-based DCF is methodologically wrong | Skips DCF, focuses on DDM and P/BV |
| CDR.WA | Gaming studio between releases: FCF near zero | Excludes P/BV and DDM from median, flags speculative premium |
| BRK-B | Diversified holding: no single right multiple | Agent notes P/BV vs. ROE is more relevant than P/E or EV/EBITDA |

## Tech stack

- **GPT-4o as orchestrator** — runs in a tool-use loop, not just text generation. Each tool call returns JSON; GPT-4o decides whether to call more tools or write the final report.
- **yfinance** — free, no API key needed, but data quality varies significantly by ticker and region. Results cached to `cache/` as JSON for 24 hours.
- **Streamlit** — single-file UI (`app.py`, ~175 lines). Session state prevents the agent from running twice on accidental double-click.
- **ReportLab** — PDF export that works on Windows without WeasyPrint/GTK dependencies.

## Cost

Each valuation runs roughly 6-8 GPT-4o API calls (one per tool + final report), totaling approximately 8,000-12,000 input tokens and 1,200-1,800 output tokens.

At current GPT-4o pricing ($2.50/1M input, $10/1M output): **~$0.04 per valuation**. Ten valuations cost roughly $0.40.

Cost spikes if the agent hits the 10-iteration limit — check terminal logs if a run seems stuck.
