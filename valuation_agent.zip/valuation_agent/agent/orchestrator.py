"""Główna pętla agenta (ValuationAgent) — wysyła zapytania do GPT-4o,
odbiera decyzje o wywołaniu narzędzi, wykonuje je i przekazuje wyniki
z powrotem do modelu aż do wygenerowania finalnego raportu.
"""

import json
import statistics
import time
from typing import Optional

from openai import OpenAI
from rich.console import Console
from rich.spinner import Spinner
from rich.live import Live

from config import OPENAI_API_KEY, MODEL, MAX_ITERATIONS, DEFAULT_TERMINAL_GROWTH
from agent.prompts import SYSTEM_PROMPT, TOOLS_DEFINITION
from tools.data_fetcher import get_financial_data, get_sector_peers
from tools.dcf import run_dcf, sensitivity_analysis
from tools.ddm import run_ddm
from tools.multiples import run_multiples
from tools.sotp import run_sotp

console = Console(legacy_windows=False)


class ValuationAgent:
    """Agent AI do wyceny spółek giełdowych.

    Orkiestruje komunikację między GPT-4o a lokalnymi narzędziami wyceny.
    GPT-4o decyduje które narzędzia wywołać — agent je wykonuje i zwraca
    wyniki do modelu, aż ten wygeneruje finalny raport.
    """

    def __init__(self) -> None:
        # Walidacja klucza API — bez niego agent nie wystartuje
        if not OPENAI_API_KEY:
            console.print(
                "[bold red]✗ Brak klucza OPENAI_API_KEY![/bold red]\n"
                "[dim]Skopiuj .env.example do .env i wpisz swój klucz OpenAI.[/dim]"
            )
            raise SystemExit(1)

        # Klient OpenAI — używany do komunikacji z GPT-4o
        self.client = OpenAI(api_key=OPENAI_API_KEY)

        # Flaga wymuszenia odświeżenia cache — ustawiana przez run() na podstawie
        # argumentu --fresh z CLI lub checkboxa w app.py
        self.force_refresh: bool = False

        # Cache danych finansowych w pamięci (na czas jednej sesji agenta).
        # Klucz: ticker, wartość: słownik z danymi z get_financial_data.
        self.financial_data_cache: dict[str, dict] = {}

        # Dziennik wywołań narzędzi — do debugowania i raportowania
        self.tool_call_log: list[dict] = []

        # Ostatnie wyniki narzędzi — do odczytu przez frontend (app.py)
        self.last_dcf_result: Optional[dict] = None
        self.last_ddm_result: Optional[dict] = None
        self.last_multiples_result: Optional[dict] = None
        self.last_sensitivity_result: Optional[dict] = None
        self.last_sotp_result: Optional[dict] = None
        self.last_market_price: Optional[float] = None

    def _ensure_financial_data(self, ticker: str) -> Optional[dict]:
        """Zwraca dane finansowe z cache sesji lub pobiera je jeśli brak.
        Gwarantuje, że narzędzia wyceny zawsze mają dane do pracy.

        Gdy self.force_refresh=True, omija cache sesji i plikowy — pobiera świeże dane.
        """
        # Pomiń cache sesji gdy force_refresh — możliwe że GPT-4o wywołuje narzędzie
        # dla peers, których dane zostały już wstępnie pobrane i chcemy je też odświeżyć
        if not self.force_refresh and ticker in self.financial_data_cache:
            return self.financial_data_cache[ticker]

        # Pobierz z yfinance (lub cache plikowego, z uwzględnieniem force_refresh)
        data = get_financial_data(ticker, force_refresh=self.force_refresh)
        if data is not None:
            self.financial_data_cache[ticker] = data
        return data

    def execute_tool(self, tool_name: str, tool_args: dict) -> str:
        """Dispatcher narzędzi — wywołuje właściwą funkcję na podstawie nazwy.

        Args:
            tool_name: Nazwa narzędzia (z odpowiedzi GPT-4o).
            tool_args: Argumenty narzędzia (sparsowane z JSON).

        Returns:
            Wynik narzędzia jako string JSON (lub komunikat o błędzie).
        """
        ticker = tool_args.get("ticker", "")

        try:
            # --- get_financial_data ---
            if tool_name == "get_financial_data":
                result = get_financial_data(ticker, force_refresh=self.force_refresh)

                if result is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return json.dumps(
                        {"error": f"Nie udało się pobrać danych dla {ticker}."},
                        ensure_ascii=False,
                    )

                self.financial_data_cache[ticker] = result
                # Zapamiętaj cenę rynkową do odczytu przez frontend
                self.last_market_price = (
                    result.get("info", {}).get("currentPrice")
                    or result.get("info", {}).get("regularMarketPrice")
                )

                # Wyświetl potencjał wg konsensusu analityków (jeśli dostępny)
                consensus = result.get("analyst_consensus", {})
                cena_rynkowa = self.last_market_price or 0
                if consensus.get("target_mean") and cena_rynkowa > 0:
                    potencjal = (consensus["target_mean"] / cena_rynkowa - 1) * 100
                    console.print(
                        f"[dim]  📈 Potencjał wg analityków: {potencjal:+.1f}%[/dim]"
                    )

                self._log_tool_call(tool_name, tool_args, success=True)
                return json.dumps(result, ensure_ascii=False, indent=2, default=str)

            # --- run_dcf ---
            if tool_name == "run_dcf":
                financial_data = self._ensure_financial_data(ticker)
                if financial_data is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return self._no_data_message(ticker)

                result = run_dcf(
                    financial_data,
                    wacc=tool_args.get("wacc"),
                    growth_rate=tool_args.get("growth_rate"),
                    terminal_growth=tool_args.get("terminal_growth"),
                    years=tool_args.get("years", 5),
                )
                if "error" not in result:
                    self.last_dcf_result = result
                self._log_tool_call(tool_name, tool_args, success="error" not in result)
                return json.dumps(result, ensure_ascii=False, indent=2, default=str)

            # --- run_multiples ---
            if tool_name == "run_multiples":
                financial_data = self._ensure_financial_data(ticker)
                if financial_data is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return self._no_data_message(ticker)

                # Pobierz peers z uwzględnieniem branży (industry-first) —
                # przekazujemy financial_data żeby uniknąć ponownego zapytania yfinance
                peers_tickers = get_sector_peers(ticker, financial_data=financial_data)
                peers_data: list[dict] = []
                for peer_ticker in peers_tickers:
                    peer = self._ensure_financial_data(peer_ticker)
                    if peer is not None:
                        peers_data.append(peer)

                result = run_multiples(financial_data, peers_data=peers_data or None)
                self.last_multiples_result = result
                self._log_tool_call(tool_name, tool_args, success=True)
                return json.dumps(result, ensure_ascii=False, indent=2, default=str)

            # --- run_ddm ---
            if tool_name == "run_ddm":
                financial_data = self._ensure_financial_data(ticker)
                if financial_data is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return self._no_data_message(ticker)

                required_return = tool_args.get("required_return")
                result = run_ddm(financial_data, required_return=required_return)

                # run_ddm zwraca None gdy brak dywidend lub model niestabilny
                if result is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return json.dumps(
                        {"info": (
                            f"DDM niedostępny dla {ticker} — brak wystarczającej "
                            "historii dywidend lub model niestabilny (g ≥ r)."
                        )},
                        ensure_ascii=False,
                    )

                self.last_ddm_result = result
                self._log_tool_call(tool_name, tool_args, success=True)
                return json.dumps(result, ensure_ascii=False, indent=2, default=str)

            # --- sensitivity_analysis ---
            if tool_name == "sensitivity_analysis":
                financial_data = self._ensure_financial_data(ticker)
                if financial_data is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return self._no_data_message(ticker)

                base_wacc = tool_args.get("base_wacc", 0.10)
                base_growth = tool_args.get("base_growth", 0.05)

                result = sensitivity_analysis(financial_data, base_wacc, base_growth)
                self.last_sensitivity_result = result
                self._log_tool_call(tool_name, tool_args, success=True)
                return json.dumps(result, ensure_ascii=False, indent=2, default=str)

            # --- run_sotp ---
            if tool_name == "run_sotp":
                financial_data = self._ensure_financial_data(ticker)
                if financial_data is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return self._no_data_message(ticker)

                result = run_sotp(financial_data)

                if result is None:
                    self._log_tool_call(tool_name, tool_args, success=False)
                    return json.dumps(
                        {"info": (
                            f"SOTP niedostępny dla {ticker} — spółka nie jest "
                            "zdefiniowana w SOTP_COMPANIES. Użyj standardowych metod."
                        )},
                        ensure_ascii=False,
                    )

                self.last_sotp_result = result
                self._log_tool_call(tool_name, tool_args, success=True)
                return json.dumps(result, ensure_ascii=False, indent=2, default=str)

            # --- Nieznane narzędzie ---
            self._log_tool_call(tool_name, tool_args, success=False)
            return json.dumps(
                {"error": f"Nieznane narzędzie: {tool_name}"},
                ensure_ascii=False,
            )

        except Exception as e:
            # Przechwycenie dowolnego błędu — agent nie powinien się wysypać
            self._log_tool_call(tool_name, tool_args, success=False)
            console.print(
                f"[bold red]✗ Błąd w narzędziu {tool_name}: {e}[/bold red]"
            )
            return json.dumps(
                {"error": f"Błąd podczas wykonywania {tool_name}: {str(e)}"},
                ensure_ascii=False,
            )

    def run(self, ticker: str, verbose: bool = False, force_refresh: bool = False) -> Optional[str]:
        """Główna pętla agenta — komunikacja z GPT-4o w cyklu tool-use.

        1. Wysyła wiadomość początkową do GPT-4o z tickerem.
        2. GPT-4o odpowiada wywołaniami narzędzi lub tekstem raportu.
        3. Agent wykonuje narzędzia i zwraca wyniki do modelu.
        4. Cykl powtarza się aż GPT-4o wygeneruje finalny tekst (bez tool calls).

        Args:
            ticker: Symbol giełdowy spółki do wyceny.
            verbose: Jeśli True, wyświetla szczegółowe logi komunikacji.

        Returns:
            Tekst raportu wyceny (Markdown) lub None w razie błędu.
        """
        # Zapisz flagę odświeżenia — execute_tool() i _ensure_financial_data()
        # odczytają ją przy każdym wywołaniu get_financial_data
        self.force_refresh = force_refresh

        console.print(
            f"\n[bold cyan]🤖 Uruchamiam agenta wyceny dla "
            f"[yellow]{ticker}[/yellow]...[/bold cyan]\n"
        )
        if force_refresh:
            console.print(
                "[yellow]  🔄 Tryb --fresh: cache plikowy zostanie pominięty "
                "— pobieram świeże dane z yfinance.[/yellow]"
            )

        # Wstaw dzisiejszą datę do system promptu — model nie zna aktualnej daty
        from datetime import date
        today = date.today().strftime("%d.%m.%Y")
        system_prompt = SYSTEM_PROMPT.replace("{today}", today)

        # Historia konwersacji z GPT-4o
        messages: list[dict] = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    f"Przeprowadź pełną wycenę spółki o tickerze: {ticker}. "
                    f"Użyj wszystkich dostępnych metod wyceny i wygeneruj "
                    f"raport w języku polskim."
                ),
            },
        ]

        # Pętla agenta — max iteracji jako zabezpieczenie
        for iteration in range(1, MAX_ITERATIONS + 1):
            if verbose:
                console.print(
                    f"[dim]  ─── Iteracja {iteration}/{MAX_ITERATIONS} "
                    f"(wiadomości: {len(messages)}) ───[/dim]"
                )

            # Zapytanie do GPT-4o z retry na rate-limit (429)
            response = None
            for _attempt in range(3):
                try:
                    with Live(
                        Spinner("dots", text="[dim]GPT-4o myśli...[/dim]"),
                        console=console,
                        transient=True,
                    ):
                        response = self.client.chat.completions.create(
                            model=MODEL,
                            messages=messages,
                            tools=TOOLS_DEFINITION,
                            tool_choice="auto",
                        )
                    break
                except Exception as e:
                    err_str = str(e)
                    if "rate_limit" in err_str or "429" in err_str:
                        wait = (_attempt + 1) * 10
                        console.print(
                            f"[yellow]  ⏳ Rate limit — czekam {wait}s "
                            f"(próba {_attempt + 1}/3)...[/yellow]"
                        )
                        time.sleep(wait)
                        if _attempt == 2:
                            console.print(
                                f"[bold red]✗ Rate limit po 3 próbach: {e}[/bold red]"
                            )
                            return None
                    else:
                        console.print(
                            f"[bold red]✗ Błąd komunikacji z OpenAI: {e}[/bold red]"
                        )
                        return None

            if response is None:
                return None

            choice = response.choices[0]
            message = choice.message

            # Dodaj odpowiedź asystenta do historii
            messages.append(message.model_dump())

            # Sprawdź czy GPT-4o chce wywołać narzędzia
            if message.tool_calls:
                if verbose:
                    names = [tc.function.name for tc in message.tool_calls]
                    console.print(
                        f"[dim]  🔧 GPT-4o wywołuje: {', '.join(names)}[/dim]"
                    )

                # Wykonaj każde żądane narzędzie i dodaj wynik do historii
                for tool_call in message.tool_calls:
                    func_name = tool_call.function.name
                    try:
                        func_args = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        func_args = {}

                    console.print(
                        f"[cyan]  ▶ {func_name}("
                        f"{', '.join(f'{k}={v!r}' for k, v in func_args.items())})"
                        f"[/cyan]"
                    )

                    # Wykonaj narzędzie
                    result_str = self.execute_tool(func_name, func_args)

                    # Wynik wraca do GPT-4o jako wiadomość tool
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": result_str,
                    })

                # Kontynuuj pętlę — GPT-4o zdecyduje co dalej
                continue

            # GPT-4o nie wywołuje narzędzi → zwrócił finalny tekst raportu
            report_text = message.content
            if report_text:
                console.print(
                    f"\n[bold green]✓ Agent zakończył analizę po "
                    f"{iteration} iteracjach "
                    f"({len(self.tool_call_log)} wywołań narzędzi).[/bold green]"
                )
                return report_text

            # Brak treści i brak tool calls — nieoczekiwany stan
            console.print(
                "[yellow]  ⚠ GPT-4o zwrócił pustą odpowiedź — "
                "proszę o kontynuację...[/yellow]"
            )
            messages.append({
                "role": "user",
                "content": "Kontynuuj analizę i wygeneruj raport.",
            })

        # Przekroczono limit iteracji
        console.print(
            f"[bold red]✗ Przekroczono limit {MAX_ITERATIONS} iteracji. "
            f"Agent nie dokończył analizy.[/bold red]"
        )
        return None

    def run_preliminary(
        self, ticker: str, force_refresh: bool = False
    ) -> Optional[dict]:
        """Etap 1: pobiera dane i uruchamia obliczenia wyceny
        (DCF, mnożniki, DDM, analiza wrażliwości) bez generowania
        narracyjnego raportu przez GPT-4o.

        Zwraca słownik z wynikami i założeniami agenta lub None w razie błędu.
        Wyniki pod kluczami zaczynającymi się od '_' to surowe dane
        przekazywane do run_final() — użytkownik ich nie widzi.
        """
        self.force_refresh = force_refresh

        console.print(
            f"\n[bold cyan]📊 Wstępna analiza dla "
            f"[yellow]{ticker}[/yellow]...[/bold cyan]\n"
        )

        # Pobierz dane finansowe z yfinance / cache
        financial_data = self._ensure_financial_data(ticker)
        if financial_data is None:
            return None

        info = financial_data.get("info") or {}
        self.last_market_price = (
            info.get("currentPrice") or info.get("regularMarketPrice")
        )

        # DCF — agent oblicza WACC z CAPM i growth z historii FCF
        dcf_result = run_dcf(financial_data)
        if "error" not in dcf_result:
            self.last_dcf_result = dcf_result

        # Wyciągnij założenia użyte przez DCF do wyświetlenia w edytorze
        zalozenia = dcf_result.get("zalozenia") or {}
        wacc_uzyte = zalozenia.get("wacc", 0.10)
        growth_uzyte = zalozenia.get("growth_rate", 0.05)

        # Oblicz współczynnik zmienności FCF (cv_fcf) — im wyższy tym bardziej
        # cykliczna spółka; próg 0.4 sugeruje użycie mediany zamiast ostatniego FCF
        fcf_historia = dcf_result.get("fcf_historyczne") or []
        cv_fcf = 0.0
        if len(fcf_historia) >= 3:
            try:
                mean_fcf = statistics.mean(fcf_historia)
                if mean_fcf != 0:
                    cv_fcf = statistics.stdev(fcf_historia) / abs(mean_fcf)
            except statistics.StatisticsError:
                cv_fcf = 0.0

        # Pobierz peers i uruchom wycenę mnożnikową
        peers_tickers = get_sector_peers(ticker, financial_data=financial_data)
        peers_data: list[dict] = []
        for peer_ticker in peers_tickers:
            peer = self._ensure_financial_data(peer_ticker)
            if peer is not None:
                peers_data.append(peer)

        multiples_result = run_multiples(
            financial_data, peers_data=peers_data or None
        )
        self.last_multiples_result = multiples_result

        # DDM — tylko jeśli spółka wypłaca dywidendy
        ddm_result = run_ddm(financial_data)
        if ddm_result is not None:
            self.last_ddm_result = ddm_result

        # Analiza wrażliwości z parametrami agenta
        sens_result = sensitivity_analysis(financial_data, wacc_uzyte, growth_uzyte)
        self.last_sensitivity_result = sens_result

        # Ceny wstępne do podglądu na ekranie edycji założeń
        dcf_cena = (
            dcf_result.get("cena_z_korekta_buyback")
            or dcf_result.get("cena_na_akcje")
        )
        mnozniki_mediana = multiples_result.get("mediana")
        waluta = (info.get("currency") or "USD").strip()

        return {
            # Założenia agenta — wyświetlane i edytowalne przez użytkownika
            "wacc_uzyte": wacc_uzyte,
            "growth_uzyte": growth_uzyte,
            "peers": list(peers_tickers),
            "cv_fcf": cv_fcf,
            # Wstępne ceny do podglądu
            "dcf_cena": dcf_cena,
            "mnozniki_mediana": mnozniki_mediana,
            "cena_rynkowa": self.last_market_price,
            "waluta": waluta,
            # Surowe wyniki przekazywane do run_final (nie wyświetlane)
            "_financial_data": financial_data,
            "_dcf_result": dcf_result,
            "_multiples_result": multiples_result,
            "_ddm_result": ddm_result,
            "_sensitivity_result": sens_result,
            "_peers_tickers": list(peers_tickers),
        }

    def run_final(
        self,
        ticker: str,
        assumptions: dict,
        wstepne: Optional[dict] = None,
        force_refresh: bool = False,
    ) -> Optional[str]:
        """Etap 2: przelicza wycenę z zatwierdzonymi założeniami użytkownika
        i generuje narracyjny raport przez GPT-4o (jedno wywołanie — bez pętli
        tool-use, wyniki obliczeń przekazywane bezpośrednio w prompcie).

        Args:
            ticker: Symbol giełdowy spółki.
            assumptions: Zatwierdzone założenia użytkownika
                         (wacc, growth, wide_moat, cykliczna, buyback, peers).
            wstepne: Wyniki z run_preliminary() — pozwala uniknąć ponownego
                     pobierania danych i obliczania mnożników gdy peers niezmienione.
            force_refresh: Czy pominąć cache yfinance.

        Returns:
            Tekst raportu wyceny w Markdown lub None w razie błędu.
        """
        self.force_refresh = force_refresh

        # Odtwórz lub pobierz dane finansowe
        if wstepne and "_financial_data" in wstepne:
            financial_data = wstepne["_financial_data"]
            self.financial_data_cache[ticker] = financial_data
        else:
            financial_data = self._ensure_financial_data(ticker)

        if financial_data is None:
            return None

        info = financial_data.get("info") or {}
        self.last_market_price = (
            info.get("currentPrice") or info.get("regularMarketPrice")
        )

        # Parametry zatwierdzone przez użytkownika
        wacc = assumptions.get("wacc", 0.10)
        growth = assumptions.get("growth", 0.05)
        wide_moat = assumptions.get("wide_moat", False)
        buyback = assumptions.get("buyback", True)
        user_peers = [p for p in (assumptions.get("peers") or []) if p]

        # Wide moat → terminal growth wyższe o 0.5pp (silna przewaga konkurencyjna
        # uzasadnia nieco wyższy wzrost w okresie terminalnym)
        terminal_growth = DEFAULT_TERMINAL_GROWTH + (0.005 if wide_moat else 0.0)

        # Przelicz DCF z zatwierdzonymi przez użytkownika parametrami
        console.print(
            f"[cyan]  ▶ run_dcf(wacc={wacc:.1%}, growth={growth:.1%}, "
            f"terminal={terminal_growth:.1%}, buyback={buyback})[/cyan]"
        )
        dcf_result = run_dcf(
            financial_data,
            wacc=wacc,
            growth_rate=growth,
            terminal_growth=terminal_growth,
            apply_buyback=buyback,
        )
        if "error" not in dcf_result:
            self.last_dcf_result = dcf_result

        # Przelicz mnożniki — tylko jeśli peers zostały zmienione przez użytkownika
        prev_peers = set((wstepne or {}).get("_peers_tickers") or [])
        peers_changed = set(user_peers) != prev_peers

        if peers_changed and user_peers:
            console.print(
                f"[cyan]  ▶ run_multiples (peers zmienione: {user_peers})[/cyan]"
            )
            peers_data: list[dict] = []
            for pt in user_peers:
                peer = self._ensure_financial_data(pt)
                if peer is not None:
                    peers_data.append(peer)
            multiples_result = run_multiples(
                financial_data, peers_data=peers_data or None
            )
        elif wstepne and "_multiples_result" in wstepne:
            # Peers niezmienione — użyj wyników z etapu 1
            multiples_result = wstepne["_multiples_result"]
            console.print("[dim]  ✓ Mnożniki bez zmian — używam wyników z etapu 1[/dim]")
        else:
            multiples_result = run_multiples(financial_data)
        self.last_multiples_result = multiples_result

        # DDM z cache etapu 1 lub ponowne obliczenie
        if wstepne and "_ddm_result" in wstepne:
            ddm_result = wstepne["_ddm_result"]
            if ddm_result is not None:
                self.last_ddm_result = ddm_result
        else:
            ddm_result = run_ddm(financial_data)
            if ddm_result is not None:
                self.last_ddm_result = ddm_result

        # Analiza wrażliwości z nowymi (zatwierdzonymi) parametrami
        sens_result = sensitivity_analysis(financial_data, wacc, growth)
        self.last_sensitivity_result = sens_result

        # Generuj narracyjny raport przez GPT-4o — jedno wywołanie bez tool-use,
        # wszystkie wyniki obliczeń przekazane bezpośrednio w treści wiadomości
        from datetime import date
        today = date.today().strftime("%d.%m.%Y")
        system_prompt = SYSTEM_PROMPT.replace("{today}", today)

        summary = {
            "ticker": ticker,
            "zatwierdzone_zalozenia": {
                "wacc": wacc,
                "growth_fcf": growth,
                "terminal_growth": terminal_growth,
                "wide_moat": wide_moat,
                "buyback": buyback,
                "peers_uzyte": user_peers,
            },
            "dcf": dcf_result,
            "multiples": multiples_result,
            "ddm": ddm_result,
            "sensitivity": sens_result,
            "cena_rynkowa": self.last_market_price,
        }

        user_msg = (
            f"Wygeneruj pełny raport wyceny dla spółki {ticker}. "
            f"Użytkownik zatwierdził następujące założenia: "
            f"WACC={wacc:.1%}, wzrost FCF={growth:.1%}, "
            f"terminal growth={terminal_growth:.1%}"
            f"{', wide moat (silna przewaga konkurencyjna)' if wide_moat else ''}"
            f"{', spółka cykliczna (użyto mediany FCF)' if assumptions.get('cykliczna') else ''}"
            f", peers: {', '.join(user_peers) if user_peers else 'domyślne'}. "
            f"Raport w języku polskim.\n\n"
            f"Wyniki obliczeń:\n"
            f"{json.dumps(summary, ensure_ascii=False, indent=2, default=str)}"
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_msg},
        ]

        console.print("\n[bold cyan]🤖 Generowanie finalnego raportu...[/bold cyan]")
        try:
            with Live(
                Spinner("dots", text="[dim]GPT-4o generuje raport...[/dim]"),
                console=console,
                transient=True,
            ):
                response = self.client.chat.completions.create(
                    model=MODEL,
                    messages=messages,
                    # Bez tools — chcemy bezpośrednio tekst raportu
                )
            report_text = response.choices[0].message.content
            if report_text:
                console.print(
                    "[bold green]✓ Raport finalny wygenerowany.[/bold green]"
                )
                return report_text
            return None
        except Exception as e:
            console.print(
                f"[bold red]✗ Błąd generowania raportu: {e}[/bold red]"
            )
            return None

    def _log_tool_call(self, tool_name: str, tool_args: dict, success: bool) -> None:
        """Zapisuje wywołanie narzędzia do dziennika."""
        self.tool_call_log.append({
            "tool": tool_name,
            "args": tool_args,
            "success": success,
        })

    @staticmethod
    def _no_data_message(ticker: str) -> str:
        """Zwraca ustandaryzowany komunikat o braku danych finansowych."""
        return json.dumps(
            {
                "error": (
                    f"Brak danych finansowych dla {ticker}. "
                    f"Najpierw wywołaj get_financial_data."
                )
            },
            ensure_ascii=False,
        )
