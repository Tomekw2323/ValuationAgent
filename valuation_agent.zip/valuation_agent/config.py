"""Konfiguracja projektu — ładowanie zmiennych środowiskowych, stałe globalne,
parametry domyślne dla modeli wyceny (np. stopa dyskontowa, stopa wzrostu).
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Ścieżka bazowa projektu (katalog w którym leży config.py)
BASE_DIR = Path(__file__).resolve().parent

# Załaduj zmienne środowiskowe z pliku .env
load_dotenv(BASE_DIR / ".env")

# Klucz API OpenAI — wymagany do komunikacji z modelem GPT-4o
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")

# Nazwa modelu OpenAI używanego przez agenta
MODEL: str = "gpt-4o"

# Maksymalna liczba iteracji pętli agenta (zabezpieczenie przed nieskończonym cyklem)
MAX_ITERATIONS: int = 10

# Folder na cache danych finansowych (względem BASE_DIR)
CACHE_DIR: Path = BASE_DIR / "cache"

# --- Domyślne parametry modeli wyceny ---

# WACC (Weighted Average Cost of Capital) — średni ważony koszt kapitału, stopa dyskontowa dla DCF
DEFAULT_WACC: float = 0.10

# Stopa wzrostu w okresie terminalnym (po okresie szczegółowej prognozy)
DEFAULT_TERMINAL_GROWTH: float = 0.025

# Liczba lat szczegółowej prognozy przepływów pieniężnych w modelu DCF
DEFAULT_PROJECTION_YEARS: int = 5
