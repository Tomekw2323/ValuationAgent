"""Aplikacja Streamlit — prosty interfejs dla Valuation Agent AI.

Uruchomienie z katalogu projektu:
    streamlit run app.py
"""

from __future__ import annotations

import os
from typing import Optional

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from dotenv import load_dotenv

# .env musi być wczytany zanim zaimportujemy config/agent (używają OPENAI_API_KEY)
load_dotenv()

from config import MODEL

st.set_page_config(page_title="Valuation Agent", page_icon="📊", layout="wide")

if not os.getenv("OPENAI_API_KEY"):
    st.error("Brak klucza OPENAI_API_KEY w pliku .env")
    st.stop()

# Inicjalizacja session_state — jednorazowo przy starcie sesji
for _k, _v in [("running", False), ("wyniki", None), ("last_params", None)]:
    if _k not in st.session_state:
        st.session_state[_k] = _v

# Formularz w sidebarze
with st.sidebar:
    st.title("⚙️ Parametry")
    ticker_raw = st.text_input("Ticker spółki", placeholder="np. AAPL, PKN.WA")
    wacc_pct   = st.slider("WACC (%)", 5.0, 20.0, 10.0, 0.5)
    growth_pct = st.slider("Wzrost FCF (%)", 0.0, 25.0, 5.0, 1.0)
    kliknieto  = st.button("▶ Wycen spółkę", type="primary",
                            use_container_width=True, disabled=st.session_state.running)
    st.caption(f"Dane: yfinance | Model: {MODEL}")

# Obsługa kliknięcia — ustaw flagę i przeładuj
if kliknieto:
    ticker = ticker_raw.strip().upper()
    if not ticker:
        st.sidebar.warning("Podaj symbol tickera.")
    else:
        params = {"ticker": ticker, "wacc": wacc_pct, "growth": growth_pct}
        if st.session_state.wyniki is None or params != st.session_state.last_params:
            st.session_state.running = True
            st.session_state.last_params = params
            st.session_state.wyniki = None
            st.rerun()
        else:
            st.sidebar.info("Wyniki sa juz zaladowane.")

# Uruchomienie agenta — tylko gdy flaga running jest aktywna
if st.session_state.running:
    ticker = st.session_state.last_params["ticker"]
    with st.spinner(f"Agent analizuje {ticker}..."):
        from agent.orchestrator import ValuationAgent
        from tools.data_fetcher import get_financial_data
        try:
            fd = get_financial_data(ticker)
            if fd is None:
                st.error(f'Nie znaleziono danych dla "{ticker}". '
                         "Sprawdz symbol (GPW: dodaj .WA, np. PKN.WA).")
            else:
                agent  = ValuationAgent()
                report = agent.run(ticker, verbose=False)
                if report is None:
                    st.error("Agent nie zdolal wygenerowac raportu. Sprobuj ponownie.")
                else:
                    info  = (agent.financial_data_cache.get(ticker) or fd).get("info", {})
                    curr  = (info.get("currency") or "USD").strip()
                    mp    = agent.last_market_price or info.get("currentPrice")
                    dcf   = agent.last_dcf_result or {}
                    mult  = agent.last_multiples_result or {}
                    sens  = agent.last_sensitivity_result or {}
                    st.session_state.wyniki = {
                        "ticker": ticker, "report": report, "curr": curr,
                        "mp": mp,
                        "dcf_price": dcf.get("cena_z_korekta_buyback") or dcf.get("cena_na_akcje"),
                        "mult_med": mult.get("mediana"), "mult": mult, "sens": sens,
                    }
        except Exception as e:
            st.error(f"Blad agenta: {e}")
            st.exception(e)
        finally:
            st.session_state.running = False  # zdejmij flagę niezależnie od wyniku
            st.rerun()

# Ekran powitalny gdy brak wyników
w = st.session_state.wyniki
if w is None:
    st.title("Valuation Agent AI")
    st.info("Podaj ticker w panelu bocznym i kliknij **Wycen spolke**.")
    st.stop()

# ─── Dashboard wyników ────────────────────────────────────────────────────────
curr, mp, dcf_p, med = w["curr"], w["mp"], w["dcf_price"], w["mult_med"]
st.title(f"Wycena: {w['ticker']}")

# 4 metryki w jednym rzędzie
c1, c2, c3, c4 = st.columns(4)
c1.metric("Cena rynkowa", f"{mp:,.2f} {curr}"    if mp    else "—")
c2.metric("DCF",          f"{dcf_p:,.2f} {curr}" if dcf_p else "—")
c3.metric("Mnozniki",     f"{med:,.2f} {curr}"   if med   else "—")
if dcf_p and mp and mp > 0:
    c4.metric("Potencjal %", f"{(dcf_p - mp) / mp * 100:+.1f}%")
else:
    c4.metric("Potencjal %", "—")

st.divider()

# Wykres scenariuszy DCF | tabela mnożników
col_l, col_r = st.columns(2)

with col_l:
    st.subheader("Scenariusze DCF")
    scen     = w["sens"].get("scenariusze") or {}
    etykiety = ["Pesymistyczny", "Bazowy", "Optymistyczny"]
    klucze   = ["pesymistyczny", "bazowy", "optymistyczny"]
    kolory   = ["#ef4444", "#6366f1", "#22c55e"]
    wartosci = [float(scen.get(k) or 0) for k in klucze]
    if any(wartosci):
        fig = go.Figure(go.Bar(
            x=etykiety, y=wartosci, marker_color=kolory, width=0.5,
            text=[f"{v:,.2f}" for v in wartosci], textposition="outside",
        ))
        if mp:
            fig.add_hline(y=mp, line_dash="dash", line_color="#f59e0b",
                          annotation_text=f"Rynek: {mp:,.2f} {curr}",
                          annotation_position="top right")
        fig.update_layout(
            height=360, showlegend=False, plot_bgcolor="white", paper_bgcolor="white",
            yaxis=dict(title=curr, range=[0, max(wartosci + ([mp] if mp else [])) * 1.3],
                       tickformat=",.0f"),
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Brak danych do wykresu scenariuszy.")

with col_r:
    st.subheader("Wyceny mnoznikowe")
    wiersze = []
    for label, klucz in [("P/E", "wycena_pe"), ("EV/EBITDA", "wycena_ev_ebitda"), ("P/BV", "wycena_pbv")]:
        blok = w["mult"].get(klucz)
        cena = blok.get("cena_na_akcje")    if isinstance(blok, dict) else None
        mnoz = blok.get("wartosc_mnoznika") if isinstance(blok, dict) else None
        wiersze.append({
            "Metoda":  label,
            "Mnoznik": f"{mnoz:.1f}x"        if mnoz else "—",
            "Wycena":  f"{cena:,.2f} {curr}" if cena else "—",
        })
    wiersze.append({"Metoda": "Mediana", "Mnoznik": "—",
                    "Wycena": f"{med:,.2f} {curr}" if med else "—"})
    st.dataframe(pd.DataFrame(wiersze), hide_index=True, use_container_width=True)

st.divider()

# Raport narracyjny GPT-4o
st.subheader("Raport agenta")
st.markdown(w["report"])

from datetime import datetime
st.download_button(
    label="Pobierz raport (.txt)", data=w["report"], mime="text/plain",
    file_name=f"wycena_{w['ticker']}_{datetime.now():%Y-%m-%d}.txt",
)

st.markdown("---")
st.caption("Wylacznie do celow edukacyjnych. Nie jest to rekomendacja inwestycyjna.")
