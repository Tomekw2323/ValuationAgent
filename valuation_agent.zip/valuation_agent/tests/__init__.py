"""Testy narzędzi wyceny."""
