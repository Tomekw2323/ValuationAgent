"""Eksport raportu wyceny do formatu PDF.

Dwie ścieżki generowania — wybór automatyczny:
1. WeasyPrint — konwertuje HTML+CSS → PDF. Idealne formatowanie, ale wymaga GTK
   (działa na Linux/Mac, problematyczne na Windows bez dodatkowych bibliotek).
2. ReportLab — czysta Python, działa wszędzie. Parsuje Markdown linia po linii
   i generuje PDF z poprawnym formatowaniem nagłówków, tabel i list.

Użycie:
    from report.pdf_generator import generate_pdf
    path = generate_pdf(raport_markdown, "AAPL")
    path = generate_pdf(raport_markdown, "AAPL", output_path="/tmp/raport.pdf")
"""

import re
from datetime import datetime
from pathlib import Path
from typing import Optional

import markdown2

from config import BASE_DIR

REPORTS_DIR = BASE_DIR / "reports"

# Kolory brandu — granatowy nagłówek, biały tekst na tle, szare krawędzie tabel
_COLOR_HEADER = "#2c3e7a"
_COLOR_ACCENT = "#f5a623"
_COLOR_LIGHT_ROW = "#f5f7ff"
_COLOR_BORDER = "#e0e0e0"
_COLOR_TEXT = "#1a1a1a"


def _output_path(ticker: str, output_path: Optional[str] = None) -> str:
    """Wyznacza ścieżkę docelową pliku PDF."""
    if output_path:
        return output_path
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    safe_ticker = ticker.replace(".", "_").upper()
    return str(REPORTS_DIR / f"wycena_{safe_ticker}_{today}.pdf")


def _build_html(raport_md: str) -> str:
    """Konwertuje Markdown raportu na pełny dokument HTML z arkuszem CSS.

    Używa markdown2 z dodatkami: tables i fenced-code-blocks.
    CSS dopasowany do typowego układu raportu GPT-4o (nagłówki sekcji,
    tabele danych finansowych, bloki ostrzeżeń w blockquote).
    """
    html_content = markdown2.markdown(
        raport_md,
        extras=["tables", "fenced-code-blocks", "strike", "break-on-newline"],
    )

    timestamp = datetime.now().strftime("%d.%m.%Y %H:%M")

    return f"""<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<style>
  body {{
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
    margin: 2cm 2.5cm;
    color: {_COLOR_TEXT};
    line-height: 1.55;
  }}
  h1 {{
    color: {_COLOR_HEADER};
    font-size: 18px;
    border-bottom: 2px solid {_COLOR_HEADER};
    padding-bottom: 4px;
    margin-top: 0;
  }}
  h2 {{
    color: {_COLOR_HEADER};
    font-size: 14px;
    margin-top: 18px;
    margin-bottom: 6px;
    border-left: 4px solid {_COLOR_ACCENT};
    padding-left: 8px;
  }}
  h3 {{
    color: {_COLOR_HEADER};
    font-size: 12px;
    margin-top: 12px;
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0;
    font-size: 10px;
  }}
  th {{
    background: {_COLOR_HEADER};
    color: white;
    padding: 5px 8px;
    text-align: left;
    font-weight: bold;
  }}
  td {{
    padding: 4px 8px;
    border-bottom: 1px solid {_COLOR_BORDER};
    vertical-align: top;
  }}
  tr:nth-child(even) td {{
    background: {_COLOR_LIGHT_ROW};
  }}
  blockquote {{
    background: #fff8e6;
    border-left: 3px solid {_COLOR_ACCENT};
    padding: 6px 12px;
    margin: 8px 0;
    font-style: italic;
    color: #555;
  }}
  code {{
    background: #f0f0f0;
    padding: 1px 4px;
    border-radius: 3px;
    font-family: "Courier New", monospace;
    font-size: 10px;
  }}
  pre code {{
    display: block;
    padding: 8px;
    white-space: pre-wrap;
  }}
  ul, ol {{
    margin: 4px 0;
    padding-left: 20px;
  }}
  li {{
    margin-bottom: 2px;
  }}
  strong {{
    color: {_COLOR_HEADER};
  }}
  .footer {{
    margin-top: 24px;
    font-size: 9px;
    color: #888;
    border-top: 1px solid {_COLOR_BORDER};
    padding-top: 8px;
    text-align: center;
  }}
</style>
</head>
<body>
{html_content}
<div class="footer">
  Wygenerowano przez Valuation Agent AI &nbsp;|&nbsp;
  Dane: yfinance &nbsp;|&nbsp; Model: GPT-4o &nbsp;|&nbsp;
  {timestamp} &nbsp;|&nbsp;
  Wyłącznie do celów informacyjnych. Nie jest rekomendacją inwestycyjną.
</div>
</body>
</html>"""


def _generate_weasyprint(html: str, path: str) -> str:
    """Generuje PDF przez WeasyPrint (Linux/Mac).

    Rzuca ImportError gdy WeasyPrint niedostępny — wywołujący przełącza na reportlab.
    """
    from weasyprint import HTML  # type: ignore
    HTML(string=html).write_pdf(path)
    return path


# ---------------------------------------------------------------------------
# ReportLab — generator PDF działający bez GTK (Windows i każdy OS)
# ---------------------------------------------------------------------------

def _rl_color(hex_color: str):
    """Konwertuje kolor hex na obiekt HexColor ReportLab."""
    from reportlab.lib.colors import HexColor  # type: ignore
    return HexColor(hex_color)


def _strip_md_inline(text: str) -> str:
    """Usuwa podstawowe znaczniki Markdown z tekstu inline.

    Zostawia tekst widoczny dla czytelnika — pogrubienie, kursywa, kod
    konwertowane na czysty tekst (ReportLab i tak zignoruje Markdown).
    """
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)   # **bold** → bold
    text = re.sub(r"\*(.+?)\*", r"\1", text)         # *italic* → italic
    text = re.sub(r"`(.+?)`", r"\1", text)           # `code` → code
    text = re.sub(r"~~(.+?)~~", r"\1", text)         # ~~strike~~ → strike
    text = re.sub(r"\[(.+?)\]\(.+?\)", r"\1", text)  # [link](url) → link
    return text.strip()


def _rl_inline_html(text: str) -> str:
    """Konwertuje Markdown inline na tagi HTML obsługiwane przez ReportLab Paragraph."""
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"\*(.+?)\*", r"<i>\1</i>", text)
    text = re.sub(r"`(.+?)`", r"<font name='Courier'>\1</font>", text)
    text = re.sub(r"\[(.+?)\]\(.+?\)", r"\1", text)
    return text


def _generate_reportlab(raport_md: str, path: str) -> str:
    """Generuje PDF przez ReportLab — parser Markdown linia po linii.

    Obsługuje:
    - Nagłówki H1 / H2 / H3 (# / ## / ###)
    - Pogrubienie i kursywa inline (**bold**, *italic*)
    - Listy punktowe (- item, * item)
    - Tabele Markdown (| col | col |)
    - Bloki kodu (```...```)
    - Bloki cytatu (> tekst)
    - Zwykłe akapity
    """
    from reportlab.lib.pagesizes import A4            # type: ignore
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore
    from reportlab.lib.units import cm                # type: ignore
    from reportlab.platypus import (                  # type: ignore
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable,
    )
    from reportlab.lib import colors                  # type: ignore
    from reportlab.lib.enums import TA_LEFT           # type: ignore

    # --- Style ---
    base_styles = getSampleStyleSheet()

    col_header = _rl_color(_COLOR_HEADER)
    col_accent = _rl_color(_COLOR_ACCENT)
    col_light = _rl_color(_COLOR_LIGHT_ROW)
    col_border = _rl_color(_COLOR_BORDER)

    style_normal = ParagraphStyle(
        "normal_rep",
        parent=base_styles["Normal"],
        fontSize=9,
        leading=13,
        textColor=_rl_color(_COLOR_TEXT),
        spaceAfter=4,
    )
    style_h1 = ParagraphStyle(
        "h1_rep",
        fontSize=16,
        leading=20,
        textColor=col_header,
        fontName="Helvetica-Bold",
        spaceBefore=6,
        spaceAfter=6,
    )
    style_h2 = ParagraphStyle(
        "h2_rep",
        fontSize=12,
        leading=16,
        textColor=col_header,
        fontName="Helvetica-Bold",
        spaceBefore=10,
        spaceAfter=4,
        leftIndent=0,
    )
    style_h3 = ParagraphStyle(
        "h3_rep",
        fontSize=10,
        leading=14,
        textColor=col_header,
        fontName="Helvetica-Bold",
        spaceBefore=6,
        spaceAfter=3,
    )
    style_bullet = ParagraphStyle(
        "bullet_rep",
        parent=style_normal,
        leftIndent=12,
        bulletIndent=4,
        spaceAfter=2,
    )
    style_code = ParagraphStyle(
        "code_rep",
        parent=style_normal,
        fontName="Courier",
        fontSize=8,
        backColor=_rl_color("#f0f0f0"),
        leftIndent=8,
        rightIndent=8,
        spaceBefore=4,
        spaceAfter=4,
    )
    style_quote = ParagraphStyle(
        "quote_rep",
        parent=style_normal,
        leftIndent=12,
        rightIndent=8,
        textColor=_rl_color("#555555"),
        backColor=_rl_color("#fff8e6"),
        spaceBefore=4,
        spaceAfter=4,
    )
    style_footer = ParagraphStyle(
        "footer_rep",
        parent=style_normal,
        fontSize=7,
        textColor=_rl_color("#888888"),
        alignment=1,  # CENTER
    )
    style_table_header = ParagraphStyle(
        "th_rep",
        parent=style_normal,
        textColor=colors.white,
        fontName="Helvetica-Bold",
        fontSize=8,
    )
    style_table_cell = ParagraphStyle(
        "td_rep",
        parent=style_normal,
        fontSize=8,
        leading=11,
    )

    # --- Parsowanie Markdown ---
    story = []
    lines = raport_md.split("\n")
    i = 0

    # Bufor dla bieżącej tabeli Markdown (| col | col |)
    table_lines: list[str] = []

    def flush_table() -> None:
        """Przetwarza zebrany bufor tabeli na obiekt Table ReportLab."""
        nonlocal table_lines
        if not table_lines:
            return

        # Odfiltruj linię separatora (|---|---|)
        rows_raw = [
            ln for ln in table_lines
            if not re.match(r"^\|[-:| ]+\|$", ln.strip())
        ]
        if not rows_raw:
            table_lines = []
            return

        # Parsuj komórki
        parsed_rows = []
        for row_ln in rows_raw:
            cells = [c.strip() for c in row_ln.strip().strip("|").split("|")]
            parsed_rows.append(cells)

        if not parsed_rows:
            table_lines = []
            return

        # Oblicz liczbę kolumn (max z wszystkich wierszy)
        n_cols = max(len(r) for r in parsed_rows)

        # Wyrównaj wiersze do n_cols
        table_data = []
        for ri, row in enumerate(parsed_rows):
            while len(row) < n_cols:
                row.append("")
            if ri == 0:
                # Wiersz nagłówka — Paragraph z białym tekstem
                table_data.append([
                    Paragraph(_strip_md_inline(c), style_table_header) for c in row
                ])
            else:
                table_data.append([
                    Paragraph(_rl_inline_html(_strip_md_inline(c)), style_table_cell) for c in row
                ])

        # Szerokości kolumn — równomierny podział szerokości kolumny treści
        available = A4[0] - 4.5 * cm   # szerokość A4 minus marginesy
        col_w = [available / n_cols] * n_cols

        tbl = Table(table_data, colWidths=col_w, repeatRows=1)
        tbl.setStyle(TableStyle([
            # Nagłówek
            ("BACKGROUND", (0, 0), (-1, 0), col_header),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
            # Komórki
            ("FONTSIZE", (1, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, col_light]),
            ("GRID", (0, 0), (-1, -1), 0.5, col_border),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 6))
        table_lines = []

    in_code_block = False

    while i < len(lines):
        line = lines[i]

        # --- Blok kodu (``` ... ```) ---
        if line.strip().startswith("```"):
            if not in_code_block:
                in_code_block = True
                flush_table()
                i += 1
                continue
            else:
                in_code_block = False
                i += 1
                continue

        if in_code_block:
            story.append(Paragraph(line or " ", style_code))
            i += 1
            continue

        # --- Linia tabeli Markdown ---
        if line.strip().startswith("|"):
            flush_table()  # flush ewentualnej poprzedniej tabeli (nie powinno być)
            table_lines.append(line)
            i += 1
            continue
        else:
            # Jeśli poprzednia linia była tabelą — spłucz bufor
            if table_lines:
                flush_table()

        stripped = line.strip()

        # --- Pusta linia ---
        if not stripped:
            story.append(Spacer(1, 4))
            i += 1
            continue

        # --- Nagłówki ---
        if stripped.startswith("### "):
            story.append(Paragraph(_rl_inline_html(stripped[4:]), style_h3))
            i += 1
            continue

        if stripped.startswith("## "):
            text = _rl_inline_html(stripped[3:])
            story.append(Spacer(1, 4))
            story.append(Paragraph(text, style_h2))
            story.append(HRFlowable(
                width="100%", thickness=0.5,
                color=col_accent, spaceAfter=3,
            ))
            i += 1
            continue

        if stripped.startswith("# "):
            story.append(Spacer(1, 6))
            story.append(Paragraph(_rl_inline_html(stripped[2:]), style_h1))
            story.append(HRFlowable(
                width="100%", thickness=1.5,
                color=col_header, spaceAfter=6,
            ))
            i += 1
            continue

        # --- Pozioma linia (--- lub ***)  ---
        if re.match(r"^[-*]{3,}$", stripped):
            story.append(Spacer(1, 4))
            story.append(HRFlowable(
                width="100%", thickness=0.5,
                color=col_border, spaceAfter=4,
            ))
            i += 1
            continue

        # --- Lista punktowa (- item  lub  * item) ---
        if re.match(r"^[-*•]\s+", stripped):
            text = re.sub(r"^[-*•]\s+", "", stripped)
            story.append(Paragraph(
                f"• {_rl_inline_html(text)}",
                style_bullet,
            ))
            i += 1
            continue

        # --- Lista numerowana (1. item) ---
        m = re.match(r"^(\d+)\.\s+(.+)$", stripped)
        if m:
            story.append(Paragraph(
                f"{m.group(1)}. {_rl_inline_html(m.group(2))}",
                style_bullet,
            ))
            i += 1
            continue

        # --- Cytat (> tekst) ---
        if stripped.startswith("> "):
            story.append(Paragraph(
                _rl_inline_html(stripped[2:]),
                style_quote,
            ))
            i += 1
            continue

        # --- Zwykły akapit ---
        story.append(Paragraph(_rl_inline_html(stripped), style_normal))
        i += 1

    # Flush ewentualnej tabeli na końcu pliku
    flush_table()

    # Stopka
    timestamp = datetime.now().strftime("%d.%m.%Y %H:%M")
    story.append(Spacer(1, 16))
    story.append(HRFlowable(width="100%", thickness=0.5, color=col_border))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        f"Wygenerowano przez Valuation Agent AI | Dane: yfinance | Model: GPT-4o | "
        f"{timestamp} | Wyłącznie do celów informacyjnych. Nie jest rekomendacją inwestycyjną.",
        style_footer,
    ))

    # --- Generowanie dokumentu ---
    doc = SimpleDocTemplate(
        path,
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        title=f"Wycena {path}",
        author="Valuation Agent AI",
    )
    doc.build(story)
    return path


def generate_pdf(
    raport_md: str,
    ticker: str,
    output_path: Optional[str] = None,
) -> str:
    """Generuje plik PDF z raportu wyceny w formacie Markdown.

    Próbuje WeasyPrint (Linux/Mac z GTK), wraca na ReportLab gdy niedostępny.

    Args:
        raport_md: Treść raportu w formacie Markdown (z GPT-4o).
        ticker: Symbol giełdowy spółki — służy do nazwy pliku.
        output_path: Pełna ścieżka docelowa. None → reports/wycena_TICKER_DATE.pdf

    Returns:
        Ścieżka do wygenerowanego pliku PDF.
    """
    path = _output_path(ticker, output_path)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    # Próba 1: WeasyPrint — idealne CSS, ale wymaga GTK (Linux/Mac)
    try:
        html = _build_html(raport_md)
        result = _generate_weasyprint(html, path)
        print(f"  📄 PDF zapisany (WeasyPrint): {result}")
        return result
    except ImportError:
        pass  # WeasyPrint niedostępny — przechodzimy na ReportLab
    except Exception as e:
        print(f"  ⚠ WeasyPrint błąd: {e} — przełączam na ReportLab")

    # Próba 2: ReportLab — czysta Python, działa wszędzie
    result = _generate_reportlab(raport_md, path)
    print(f"  📄 PDF zapisany (ReportLab): {result}")
    return result
