"""Formatowanie i zapis raportu wyceny — renderowanie w terminalu
za pomocą biblioteki rich, eksport do pliku Markdown (.md).
"""

from datetime import datetime

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule

from config import BASE_DIR

console = Console(legacy_windows=False)

# Folder na zapisane raporty (obok głównego katalogu projektu)
REPORTS_DIR = BASE_DIR / "reports"


def display_report(report_text: str, ticker: str) -> None:
    """Wyświetla raport wyceny w terminalu z formatowaniem rich.

    Args:
        report_text: Treść raportu w formacie Markdown (z GPT-4o).
        ticker: Symbol giełdowy spółki.
    """
    today = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Nagłówek raportu
    console.print()
    console.print(Rule(style="cyan"))
    console.print(
        Panel(
            f"[bold white]RAPORT WYCENY: [yellow]{ticker.upper()}[/yellow][/bold white]\n"
            f"[dim]Data analizy: {today}[/dim]",
            style="cyan",
            padding=(1, 4),
        )
    )
    console.print(Rule(style="cyan"))
    console.print()

    # Treść raportu renderowana jako Markdown
    md = Markdown(report_text)
    console.print(md)

    # Stopka
    console.print()
    console.print(Rule(style="cyan"))
    console.print(
        "[dim]Wygenerowano przez Valuation Agent AI | "
        "Dane: yfinance | Model: GPT-4o[/dim]",
        justify="center",
    )
    console.print(Rule(style="cyan"))
    console.print()


def save_report(report_text: str, ticker: str, tool_log: list) -> str:
    """Zapisuje raport wyceny do pliku Markdown.

    Args:
        report_text: Treść raportu (Markdown z GPT-4o).
        ticker: Symbol giełdowy spółki.
        tool_log: Lista wywołanych narzędzi [{tool, args, success}, ...].

    Returns:
        Ścieżka do zapisanego pliku.
    """
    # Utwórz folder reports/ jeśli nie istnieje
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    # Nazwa pliku: TICKER_YYYY-MM-DD.md (kropki w tickerze zamienione na _)
    today = datetime.now().strftime("%Y-%m-%d")
    safe_ticker = ticker.replace(".", "_").upper()
    filename = f"{safe_ticker}_{today}.md"
    filepath = REPORTS_DIR / filename

    # Statystyki narzędzi
    total_calls = len(tool_log)
    successful = sum(1 for t in tool_log if t.get("success"))
    failed = total_calls - successful

    # Budowanie zawartości pliku
    lines: list[str] = []

    # YAML frontmatter — metadane raportu
    lines.append("---")
    lines.append(f"ticker: {ticker}")
    lines.append(f"data: {today}")
    lines.append(f"narzedzia_wywolane: {total_calls}")
    lines.append(f"narzedzia_sukces: {successful}")
    lines.append(f"narzedzia_blad: {failed}")
    lines.append("---")
    lines.append("")

    # Treść raportu
    lines.append(report_text)
    lines.append("")

    # Sekcja z logiem wywołanych narzędzi
    lines.append("---")
    lines.append("")
    lines.append("## Wywołane narzędzia")
    lines.append("")

    if tool_log:
        lines.append("| # | Narzędzie | Argumenty | Status |")
        lines.append("|---|-----------|-----------|--------|")
        for i, entry in enumerate(tool_log, 1):
            tool_name = entry.get("tool", "?")
            args = entry.get("args", {})
            status = "✓" if entry.get("success") else "✗"

            # Zwięzłe argumenty — tylko klucze i wartości
            args_str = ", ".join(f"{k}={v}" for k, v in args.items())
            if len(args_str) > 60:
                args_str = args_str[:57] + "..."

            lines.append(f"| {i} | `{tool_name}` | {args_str} | {status} |")
    else:
        lines.append("*Brak wywołań narzędzi.*")

    lines.append("")
    lines.append(f"*Raport wygenerowany: {today} przez Valuation Agent AI*")

    # Zapis do pliku
    content = "\n".join(lines)
    filepath.write_text(content, encoding="utf-8")

    console.print(
        f"\n[bold green]💾 Raport zapisany: [white]{filepath}[/white][/bold green]"
    )

    return str(filepath)
